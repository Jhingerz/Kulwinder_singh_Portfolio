# Kulwinder OS

Premium marketing automation portfolio.

## Run
npm install
npm run dev

## Deploy
Push to GitHub and import into Vercel.
