export default function Home(){
return (
<main style={{padding:'40px',fontFamily:'sans-serif',background:'#0b1120',color:'white',minHeight:'100vh'}}>
<h1>Kulwinder Singh</h1>
<h2>Marketing Automation Architect</h2>
<p>Customer Lifecycle Strategist • AI-Powered Growth Leader</p>

<h3>Awards</h3>
<ul>
<li>CEO Recognition Award - Way.com</li>
<li>Wayfarer Award - Way.com</li>
</ul>

<h3>Platforms</h3>
<ul>
<li>Klaviyo</li>
<li>HubSpot</li>
<li>Salesforce Marketing Cloud</li>
<li>SendGrid</li>
</ul>

<h3>AI Stack</h3>
<ul>
<li>ChatGPT</li>
<li>Claude</li>
<li>Gemini</li>
<li>Perplexity</li>
<li>GitHub Copilot</li>
</ul>
</main>
)
}